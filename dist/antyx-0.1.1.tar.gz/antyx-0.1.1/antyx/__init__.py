__version__ = "0.1"
__name__ = "antyx"
__author__ = "Daniel Rodrigálvarez Morente"
__email__ = "drm.datos@gmail.com"
